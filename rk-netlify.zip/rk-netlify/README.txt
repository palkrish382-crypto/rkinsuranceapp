RK Insurance app - Netlify setup
1. Put this folder on GitHub (or use Netlify CLI: netlify deploy --prod).
2. Netlify > Add new site > Import from Git > choose the repo. No build command needed.
3. Site settings > Environment variables, add:
   STAFF_PASSWORD = (your own password for the Tracker tab)
   WA_PHONE       = +919930943076
   CALLMEBOT_KEY  = (key you get from CallMeBot, see below)
4. WhatsApp alert setup (CallMeBot, free): from 9930943076 follow the steps at
   callmebot.com (WhatsApp section) to get your API key, then paste it above.
5. Redeploy. Open the app > Tracker > enter your password > add customers.
